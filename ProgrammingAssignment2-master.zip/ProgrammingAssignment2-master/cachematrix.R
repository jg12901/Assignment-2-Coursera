## Put comments here that give an overall description of what your
## functions do

## Write a short comment describing this function
## This function creates a matrix object that can cache its inverse
makeCacheMatrix <- function(x = matrix()) {
  m <- NULL
  set <- function(y) {
    x <<- y
    m <<- NULL	
  }
  get <- function() x
  setinv <- function(inverse) m <<- inverse
  getinv <- function() m
  list(set = set, get = get,setinv = setinv, getinv = getinv)
}

## Write a short comment describing this function
## The function will compute the inverse of the special matrix created by makeCacheMatrix.
## If the inverse has already been calculated (and the matrix hasn't changed), then it should
## retrieve the inverse from the cache
cacheSolve <- function(x, ...) {
  ## Return a matrix that is the inverse of 'x'
  m <- x$getinv()
  if(!is.null(m)) {
    print("getting cached data")
    return(m)
  }
  matrix1 <- x$get()
  m <- solve(matrix1, ...)
  x$setinv(m)
  m
}